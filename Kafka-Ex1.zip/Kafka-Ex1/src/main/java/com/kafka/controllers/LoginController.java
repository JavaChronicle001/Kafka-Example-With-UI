package com.kafka.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.kafka.db.configuration.model.User;
import com.kafka.db.configuration.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {
	@Autowired
	private UserRepository userRepository;

	@GetMapping("/login")
	public String showLoginForm() {
		return "login.html";
	}

	@PostMapping("/login")
	public String loginUser(@RequestParam String email, HttpSession session, Model model) {
		// Validate email (e.g., against database)
		if (isValidEmail(email)) {
			// Set user session attribute
			model.addAttribute("currentUser", email);
			model.addAttribute("users", this.userRepository.findAll());
			return "messaging.html";
		} else {
			// Invalid email, redirect back to login page with error message
			return "redirect:/login?error";
		}
	}

	private boolean isValidEmail(String email) {
		// Perform validation (e.g., check against database)
		// For demonstration, assume all emails are valid
		User user = userRepository.findByEmail(email);
		if (user == null)
			return false;
		return true;
	}

}
