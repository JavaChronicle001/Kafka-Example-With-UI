package com.kafka.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.kafka.db.configuration.model.User;
import com.kafka.db.configuration.repository.UserRepository;

import jakarta.servlet.http.HttpSession;

@Controller
public class MessagingController {
	@Autowired
	private UserRepository userRepository;

	@GetMapping("/messaging")
	public String showMessagingPage(Model model, HttpSession session) {
		User currentUser = (User) session.getAttribute("user");
		model.addAttribute("currentUser", currentUser.getEmail());
		model.addAttribute("users", this.userRepository.findAll());
		return "messaging.html";
	}
}
