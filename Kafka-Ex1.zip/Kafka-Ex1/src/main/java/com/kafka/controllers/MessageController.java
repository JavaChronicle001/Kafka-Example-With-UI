package com.kafka.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kafka.db.configuration.dto.MessageDTO;
import com.kafka.db.configuration.model.Message;
import com.kafka.db.configuration.model.User;
import com.kafka.db.configuration.repository.MessageRepository;
import com.kafka.db.configuration.repository.UserRepository;
import com.kafka.normal.configuration.KafkaProducerService;

@RestController
public class MessageController {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private MessageRepository messageRepository;

	@Autowired
	private KafkaProducerService kafkaProducerService;

	@Autowired
	private SimpMessagingTemplate simpMessagingTemplate;

	@PostMapping("/messages/send")
	public ResponseEntity<String> sendMessage(@RequestParam String senderEmail, @RequestParam String recipientEmail,
			@RequestParam String message) {
		User sender = userRepository.findByEmail(senderEmail);
		User recipient = userRepository.findByEmail(recipientEmail);

		if (sender == null || recipient == null) {
			return ResponseEntity.badRequest().body("Sender or recipient not found");
		}

		Message newMessage = new Message();
		newMessage.setSender(sender);
		newMessage.setRecipient(recipient);
		newMessage.setMessageText(message);

		messageRepository.save(newMessage);

		String kafkaMessage = String.format("%s sent a message to %s: %s", sender.getUsername(),
				recipient.getUsername(), message);
		kafkaProducerService.sendMessage("my-topic", kafkaMessage);

		simpMessagingTemplate.convertAndSend("/topic/messages/" + recipientEmail, new MessageDTO(newMessage.getId(),
				sender.getEmail(), recipient.getEmail(), newMessage.getMessageText()));

		// Also send the message to the sender
		simpMessagingTemplate.convertAndSend("/topic/messages/" + senderEmail, new MessageDTO(newMessage.getId(),
				sender.getEmail(), recipient.getEmail(), newMessage.getMessageText()));

		return ResponseEntity.ok("Message sent successfully");
	}

	@MessageMapping("/sendMessage")
	@SendTo("/topic/messages")
	public MessageDTO broadcastMessage(MessageDTO messagePayload) {
		return messagePayload;
	}

	@GetMapping("/messages/user/{email}")
	public ResponseEntity<List<MessageDTO>> getMessagesForUser(@PathVariable String email) {
		List<Message> messages = messageRepository.findMessagesForUser(email);
		List<MessageDTO> messagesDTO = messages.stream().map(message -> new MessageDTO(message.getId(),
				message.getSender().getEmail(), message.getRecipient().getEmail(), message.getMessageText()))
				.collect(Collectors.toList());
		return ResponseEntity.ok(messagesDTO);
	}
}
