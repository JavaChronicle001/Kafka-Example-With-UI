package com.kafka.db.configuration.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.kafka.db.configuration.model.Message;
import com.kafka.db.configuration.model.User;

@Repository
public interface MessageRepository extends JpaRepository<Message, Long> {

	List<Message> findByRecipient(User recipient);

	@Query("SELECT m FROM Message m WHERE m.sender.email = :email OR m.recipient.email = :email ORDER BY m.id ASC")
	List<Message> findMessagesForUser(@Param("email") String email);

}
