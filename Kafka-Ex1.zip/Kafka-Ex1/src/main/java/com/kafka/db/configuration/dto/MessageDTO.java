package com.kafka.db.configuration.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MessageDTO {
	private Long id;
	private String senderEmail;
	private String recipientEmail;
	private String messageText;

	public MessageDTO(Long id, String senderEmail, String recipientEmail, String messageText) {
		this.id = id;
		this.senderEmail = senderEmail;
		this.recipientEmail = recipientEmail;
		this.messageText = messageText;
	}
}
