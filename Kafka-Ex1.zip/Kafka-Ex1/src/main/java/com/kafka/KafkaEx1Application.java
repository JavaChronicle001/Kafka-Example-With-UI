package com.kafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaEx1Application {

	public static void main(String[] args) {
		SpringApplication.run(KafkaEx1Application.class, args);
	}

}
